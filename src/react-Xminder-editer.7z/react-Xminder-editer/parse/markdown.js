import { transformToMarkdown } from './toMarkdown'
import { transformMarkdownTo } from './markdownTo'

export default {
  transformToMarkdown,
  transformMarkdownTo
}
